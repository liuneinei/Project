exports.app_key = "661d506a03eb01faf054799eab35225d"; //请在此行填写从阿拉丁后台获取的appkey
exports.getLocation = true; //默认不获取用户坐标位置
exports.getUserinfo = true; //默认不获取用户头像昵称
exports.appid = "wxa138734d6e218b77"; //用于用户登录、微信转发群信息、二维码等微信官方功能
exports.appsecret = "e5dfaea186647a4264592b5395234ea6";//用于用户登录、微信转发群信息、二维码等微信官方功能